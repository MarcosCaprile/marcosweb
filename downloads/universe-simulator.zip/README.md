# 3D Universe Simulator (N-Body)

Interactive 3D simulation of the Solar System using real gravitational physics.  
All planets and the Moon move according to Newton's law of gravity in an N-body system.

© Marcos Caprile 2025

## Features
- Realistic planetary motion (Newtonian gravity)
- N-body simulation (all bodies influence each other)
- Moon orbiting Earth
- Adjustable simulation speed
- Camera follow mode for planets
- Zoom with mouse wheel
- Background stars
- Planet sizes scaled from real radii (visually compressed)

## Requirements
- Python 3.11+ (recommended)
- numpy
- matplotlib

## Install
pip install numpy matplotlib

## Run
python universe_simulator.py

## Controls
- Mouse wheel → Zoom in/out
- Click + drag → Rotate view
- Slider → Change simulation speed
- Radio buttons → Follow a planet

## Physics Model
Units used in the simulation:
- Distance: Astronomical Units (AU)
- Time: Years
- Mass: Solar masses

This simplifies the gravitational constant to:

G = 4π²

Motion is integrated using the Velocity-Verlet algorithm for stable orbits.

## Notes
This is an educational simulation. It does not include:
- Relativistic effects
- Perfect NASA orbital data
- Non-spherical gravity fields

If no window appears on Linux, install Tk:
sudo apt-get install python3-tk

## License
Free for educational use.  
You may modify and share this project, but credit must be given:

© Marcos Caprile 2025
